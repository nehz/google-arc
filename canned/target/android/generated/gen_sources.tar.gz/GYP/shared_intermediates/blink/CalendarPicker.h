namespace blink {
extern const char calendarPickerCss[4348];
extern const char calendarPickerJs[82378];
extern const char pickerButtonCss[1289];
extern const char suggestionPickerCss[856];
extern const char suggestionPickerJs[9025];
}
