namespace WebCore {
extern const char cachePolyfillJs[2083];
}
