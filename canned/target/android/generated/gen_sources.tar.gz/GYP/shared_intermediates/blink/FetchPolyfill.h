namespace WebCore {
extern const char fetchPolyfillJs[563];
}
