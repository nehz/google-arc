namespace blink {
extern const char pickerCommonCss[145];
extern const char pickerCommonJs[4790];
}
