namespace blink {
extern const char colorSuggestionPickerCss[666];
extern const char colorSuggestionPickerJs[4136];
}
