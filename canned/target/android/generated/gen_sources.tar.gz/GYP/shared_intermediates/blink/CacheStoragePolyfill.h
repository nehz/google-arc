namespace WebCore {
extern const char cacheStoragePolyfillJs[1827];
}
