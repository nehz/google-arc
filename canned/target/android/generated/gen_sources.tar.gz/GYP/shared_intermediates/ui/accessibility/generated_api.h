// Copyright (c) 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// GENERATED FROM THE API DEFINITIONS IN
//   ui/accessibility
// DO NOT EDIT.

#ifndef UI_ACCESSIBILITY_GENERATED_API_H__
#define UI_ACCESSIBILITY_GENERATED_API_H__

#include <string>

#include "base/basictypes.h"

class ExtensionFunctionRegistry;


class GeneratedFunctionRegistry {
 public:
  static void RegisterAll(ExtensionFunctionRegistry* registry);
};


#endif  // UI_ACCESSIBILITY_GENERATED_API_H__
