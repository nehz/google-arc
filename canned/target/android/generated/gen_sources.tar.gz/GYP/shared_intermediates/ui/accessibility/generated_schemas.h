// Copyright (c) 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// GENERATED FROM THE API DEFINITIONS IN
//   ui/accessibility
// DO NOT EDIT.

#ifndef UI_ACCESSIBILITY_GENERATED_SCHEMAS_H__
#define UI_ACCESSIBILITY_GENERATED_SCHEMAS_H__

#include <map>
#include <string>

#include "base/strings/string_piece.h"


class GeneratedSchemas {
 public:
  // Determines if schema named |name| is generated.
  static bool IsGenerated(std::string name);

  // Gets the API schema named |name|.
  static base::StringPiece Get(const std::string& name);
};


#endif  // UI_ACCESSIBILITY_GENERATED_SCHEMAS_H__
