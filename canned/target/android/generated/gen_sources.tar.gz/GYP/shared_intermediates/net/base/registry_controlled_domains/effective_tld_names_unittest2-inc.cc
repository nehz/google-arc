/* This file is generated. DO NOT EDIT!

The byte array encodes effective tld names. See make_dafsa.py for documentation.*/

const unsigned char kDafsa[9] = {
  0x02, 0x84, 0x62, 0x61, 0x72, 0x2e, 0x6a, 0x70, 0x80,
};
