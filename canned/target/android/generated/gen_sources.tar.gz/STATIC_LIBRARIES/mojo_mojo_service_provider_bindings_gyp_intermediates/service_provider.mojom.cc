// Copyright 2013 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#if defined(__clang__)
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-private-field"
#endif

#include "mojo/public/interfaces/service_provider/service_provider.mojom.h"

#include "mojo/public/cpp/bindings/lib/array_serialization.h"
#include "mojo/public/cpp/bindings/lib/bindings_serialization.h"
#include "mojo/public/cpp/bindings/lib/bounds_checker.h"
#include "mojo/public/cpp/bindings/lib/message_builder.h"
#include "mojo/public/cpp/bindings/lib/string_serialization.h"
#include "mojo/public/cpp/bindings/lib/validation_errors.h"
namespace mojo {


namespace internal {
namespace {

#pragma pack(push, 1)
const uint32_t kServiceProvider_ConnectToService_Name = 0;

class ServiceProvider_ConnectToService_Params_Data {
 public:
  static ServiceProvider_ConnectToService_Params_Data* New(mojo::internal::Buffer* buf) {
    return new (buf->Allocate(sizeof(ServiceProvider_ConnectToService_Params_Data)))
        ServiceProvider_ConnectToService_Params_Data();
  }

  static bool Validate(const void* data,
                       mojo::internal::BoundsChecker* bounds_checker) {
    
      if (!data)
        return true;
    
      if (!ValidateStructHeader(
              data, sizeof(ServiceProvider_ConnectToService_Params_Data),
              4, bounds_checker)) {
        return false;
      }
    
      const ServiceProvider_ConnectToService_Params_Data* MOJO_ALLOW_UNUSED object =
          static_cast<const ServiceProvider_ConnectToService_Params_Data*>(data);
      if (!mojo::internal::ValidateEncodedPointer(&object->service_url.offset)) {
        ReportValidationError(mojo::internal::VALIDATION_ERROR_ILLEGAL_POINTER);
        return false;
      }
      if (!mojo::String::Data_::Validate(
              mojo::internal::DecodePointerRaw(&object->service_url.offset),
              bounds_checker)) {
        return false;
      }
      if (!mojo::internal::ValidateEncodedPointer(&object->service_name.offset)) {
        ReportValidationError(mojo::internal::VALIDATION_ERROR_ILLEGAL_POINTER);
        return false;
      }
      if (!mojo::String::Data_::Validate(
              mojo::internal::DecodePointerRaw(&object->service_name.offset),
              bounds_checker)) {
        return false;
      }
      if (!bounds_checker->ClaimHandle(object->client_handle)) {
        ReportValidationError(mojo::internal::VALIDATION_ERROR_ILLEGAL_HANDLE);
        return false;
      }
      if (!mojo::internal::ValidateEncodedPointer(&object->requestor_url.offset)) {
        ReportValidationError(mojo::internal::VALIDATION_ERROR_ILLEGAL_POINTER);
        return false;
      }
      if (!mojo::String::Data_::Validate(
              mojo::internal::DecodePointerRaw(&object->requestor_url.offset),
              bounds_checker)) {
        return false;
      }
    
      return true;
  }

  mojo::internal::StructHeader header_;

  mojo::internal::StringPointer service_url;
  mojo::internal::StringPointer service_name;
  mojo::MessagePipeHandle client_handle;
  uint8_t pad2_[4];
  mojo::internal::StringPointer requestor_url;

  void EncodePointersAndHandles(std::vector<mojo::Handle>* handles) {
    
    mojo::internal::Encode(&service_url, handles);
    mojo::internal::Encode(&service_name, handles);
    mojo::internal::EncodeHandle(&client_handle, handles);
    mojo::internal::Encode(&requestor_url, handles);
  }

  void DecodePointersAndHandles(std::vector<mojo::Handle>* handles) {
    
    mojo::internal::Decode(&service_url, handles);
    mojo::internal::Decode(&service_name, handles);
    mojo::internal::DecodeHandle(&client_handle, handles);
    mojo::internal::Decode(&requestor_url, handles);
  }

 private:
  ServiceProvider_ConnectToService_Params_Data() {
    header_.num_bytes = sizeof(*this);
    header_.num_fields = 4;
  }
};
MOJO_COMPILE_ASSERT(sizeof(ServiceProvider_ConnectToService_Params_Data) == 40,
                    bad_sizeof_ServiceProvider_ConnectToService_Params_Data);


#pragma pack(pop)

}  // namespace


}  // namespace internal
const char* ServiceProvider::Name_ = "mojo::ServiceProvider";


ServiceProviderProxy::ServiceProviderProxy(mojo::MessageReceiverWithResponder* receiver)
    : receiver_(receiver) {
}
void ServiceProviderProxy::ConnectToService(
    const mojo::String& in_service_url, const mojo::String& in_service_name, mojo::ScopedMessagePipeHandle in_client_handle, const mojo::String& in_requestor_url) {
  size_t payload_size =
      mojo::internal::Align(sizeof(internal::ServiceProvider_ConnectToService_Params_Data));
  payload_size += GetSerializedSize_(in_service_url);
  payload_size += GetSerializedSize_(in_service_name);
  payload_size += GetSerializedSize_(in_requestor_url);
  mojo::internal::MessageBuilder builder(internal::kServiceProvider_ConnectToService_Name, payload_size);

  internal::ServiceProvider_ConnectToService_Params_Data* params =
      internal::ServiceProvider_ConnectToService_Params_Data::New(builder.buffer());

  Serialize_(mojo::internal::Forward(in_service_url), builder.buffer(), &params->service_url.ptr);
  Serialize_(mojo::internal::Forward(in_service_name), builder.buffer(), &params->service_name.ptr);
  params->client_handle = in_client_handle.release();
  Serialize_(mojo::internal::Forward(in_requestor_url), builder.buffer(), &params->requestor_url.ptr);
  mojo::Message message;
  params->EncodePointersAndHandles(message.mutable_handles());
  builder.Finish(&message);
  bool ok MOJO_ALLOW_UNUSED = receiver_->Accept(&message);
  // This return value may be ignored as !ok implies the Connector has
  // encountered an error, which will be visible through other means.
}

ServiceProviderStub::ServiceProviderStub()
    : sink_(NULL) {
}

bool ServiceProviderStub::Accept(mojo::Message* message) {
  switch (message->header()->name) {
    case internal::kServiceProvider_ConnectToService_Name: {
      internal::ServiceProvider_ConnectToService_Params_Data* params =
          reinterpret_cast<internal::ServiceProvider_ConnectToService_Params_Data*>(
              message->mutable_payload());

      params->DecodePointersAndHandles(message->mutable_handles());
      
      mojo::String p1;
      Deserialize_(params->service_url.ptr, &p1);
      
      mojo::String p2;
      Deserialize_(params->service_name.ptr, &p2);
      
      mojo::String p4;
      Deserialize_(params->requestor_url.ptr, &p4);
      sink_->ConnectToService(p1, p2, mojo::MakeScopedHandle(mojo::internal::FetchAndReset(&params->client_handle)), p4);
      return true;
    }
  }
  return false;
}

bool ServiceProviderStub::AcceptWithResponder(
    mojo::Message* message, mojo::MessageReceiver* responder) {
  switch (message->header()->name) {
    case internal::kServiceProvider_ConnectToService_Name: {
      break;
    }
  }
  return false;
}

ServiceProviderRequestValidator::ServiceProviderRequestValidator(
    mojo::MessageReceiver* sink) : MessageFilter(sink) {
}

bool ServiceProviderRequestValidator::Accept(mojo::Message* message) {
  switch (message->header()->name) {
    case internal::kServiceProvider_ConnectToService_Name: {
      if (message->has_flag(mojo::internal::kMessageExpectsResponse) ||
          message->has_flag(mojo::internal::kMessageIsResponse)) {
        break;
      }
      mojo::internal::BoundsChecker bounds_checker(
          message->payload(), message->payload_num_bytes(),
          message->handles()->size());
      if (!internal::ServiceProvider_ConnectToService_Params_Data::Validate(
              message->payload(), &bounds_checker)) {
        return false;
      }
      break;
    }
  }

  return sink_->Accept(message);
}

}  // namespace mojo

#if defined(__clang__)
#pragma clang diagnostic pop
#endif
