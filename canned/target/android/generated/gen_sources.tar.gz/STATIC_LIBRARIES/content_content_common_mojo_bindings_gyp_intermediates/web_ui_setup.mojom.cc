// Copyright 2013 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#if defined(__clang__)
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-private-field"
#endif

#include "content/common/web_ui_setup.mojom.h"

#include "mojo/public/cpp/bindings/lib/array_serialization.h"
#include "mojo/public/cpp/bindings/lib/bindings_serialization.h"
#include "mojo/public/cpp/bindings/lib/bounds_checker.h"
#include "mojo/public/cpp/bindings/lib/message_builder.h"
#include "mojo/public/cpp/bindings/lib/string_serialization.h"
#include "mojo/public/cpp/bindings/lib/validation_errors.h"
namespace content {


namespace internal {
namespace {

#pragma pack(push, 1)
const uint32_t kWebUISetup_SetWebUIHandle_Name = 0;

class WebUISetup_SetWebUIHandle_Params_Data {
 public:
  static WebUISetup_SetWebUIHandle_Params_Data* New(mojo::internal::Buffer* buf) {
    return new (buf->Allocate(sizeof(WebUISetup_SetWebUIHandle_Params_Data)))
        WebUISetup_SetWebUIHandle_Params_Data();
  }

  static bool Validate(const void* data,
                       mojo::internal::BoundsChecker* bounds_checker) {
    
      if (!data)
        return true;
    
      if (!ValidateStructHeader(
              data, sizeof(WebUISetup_SetWebUIHandle_Params_Data),
              2, bounds_checker)) {
        return false;
      }
    
      const WebUISetup_SetWebUIHandle_Params_Data* MOJO_ALLOW_UNUSED object =
          static_cast<const WebUISetup_SetWebUIHandle_Params_Data*>(data);
      if (!bounds_checker->ClaimHandle(object->web_ui_handle)) {
        ReportValidationError(mojo::internal::VALIDATION_ERROR_ILLEGAL_HANDLE);
        return false;
      }
    
      return true;
  }

  mojo::internal::StructHeader header_;

  int32_t view_routing_id;
  mojo::MessagePipeHandle web_ui_handle;

  void EncodePointersAndHandles(std::vector<mojo::Handle>* handles) {
    
    mojo::internal::EncodeHandle(&web_ui_handle, handles);
  }

  void DecodePointersAndHandles(std::vector<mojo::Handle>* handles) {
    
    mojo::internal::DecodeHandle(&web_ui_handle, handles);
  }

 private:
  WebUISetup_SetWebUIHandle_Params_Data() {
    header_.num_bytes = sizeof(*this);
    header_.num_fields = 2;
  }
};
MOJO_COMPILE_ASSERT(sizeof(WebUISetup_SetWebUIHandle_Params_Data) == 16,
                    bad_sizeof_WebUISetup_SetWebUIHandle_Params_Data);


#pragma pack(pop)

}  // namespace


}  // namespace internal
const char* WebUISetupClient::Name_ = "content::WebUISetupClient";


WebUISetupClientProxy::WebUISetupClientProxy(mojo::MessageReceiverWithResponder* receiver)
    : receiver_(receiver) {
}

WebUISetupClientStub::WebUISetupClientStub()
    : sink_(NULL) {
}

bool WebUISetupClientStub::Accept(mojo::Message* message) {
  return false;
}

bool WebUISetupClientStub::AcceptWithResponder(
    mojo::Message* message, mojo::MessageReceiver* responder) {
  return false;
}

WebUISetupClientRequestValidator::WebUISetupClientRequestValidator(
    mojo::MessageReceiver* sink) : MessageFilter(sink) {
}

bool WebUISetupClientRequestValidator::Accept(mojo::Message* message) {

  return sink_->Accept(message);
}

const char* WebUISetup::Name_ = "content::WebUISetup";


WebUISetupProxy::WebUISetupProxy(mojo::MessageReceiverWithResponder* receiver)
    : receiver_(receiver) {
}
void WebUISetupProxy::SetWebUIHandle(
    int32_t in_view_routing_id, mojo::ScopedMessagePipeHandle in_web_ui_handle) {
  size_t payload_size =
      mojo::internal::Align(sizeof(internal::WebUISetup_SetWebUIHandle_Params_Data));
  mojo::internal::MessageBuilder builder(internal::kWebUISetup_SetWebUIHandle_Name, payload_size);

  internal::WebUISetup_SetWebUIHandle_Params_Data* params =
      internal::WebUISetup_SetWebUIHandle_Params_Data::New(builder.buffer());

  params->view_routing_id = in_view_routing_id;
  params->web_ui_handle = in_web_ui_handle.release();
  mojo::Message message;
  params->EncodePointersAndHandles(message.mutable_handles());
  builder.Finish(&message);
  bool ok MOJO_ALLOW_UNUSED = receiver_->Accept(&message);
  // This return value may be ignored as !ok implies the Connector has
  // encountered an error, which will be visible through other means.
}

WebUISetupStub::WebUISetupStub()
    : sink_(NULL) {
}

bool WebUISetupStub::Accept(mojo::Message* message) {
  switch (message->header()->name) {
    case internal::kWebUISetup_SetWebUIHandle_Name: {
      internal::WebUISetup_SetWebUIHandle_Params_Data* params =
          reinterpret_cast<internal::WebUISetup_SetWebUIHandle_Params_Data*>(
              message->mutable_payload());

      params->DecodePointersAndHandles(message->mutable_handles());
      
      sink_->SetWebUIHandle(params->view_routing_id, mojo::MakeScopedHandle(mojo::internal::FetchAndReset(&params->web_ui_handle)));
      return true;
    }
  }
  return false;
}

bool WebUISetupStub::AcceptWithResponder(
    mojo::Message* message, mojo::MessageReceiver* responder) {
  switch (message->header()->name) {
    case internal::kWebUISetup_SetWebUIHandle_Name: {
      break;
    }
  }
  return false;
}

WebUISetupRequestValidator::WebUISetupRequestValidator(
    mojo::MessageReceiver* sink) : MessageFilter(sink) {
}

bool WebUISetupRequestValidator::Accept(mojo::Message* message) {
  switch (message->header()->name) {
    case internal::kWebUISetup_SetWebUIHandle_Name: {
      if (message->has_flag(mojo::internal::kMessageExpectsResponse) ||
          message->has_flag(mojo::internal::kMessageIsResponse)) {
        break;
      }
      mojo::internal::BoundsChecker bounds_checker(
          message->payload(), message->payload_num_bytes(),
          message->handles()->size());
      if (!internal::WebUISetup_SetWebUIHandle_Params_Data::Validate(
              message->payload(), &bounds_checker)) {
        return false;
      }
      break;
    }
  }

  return sink_->Accept(message);
}

}  // namespace content

#if defined(__clang__)
#pragma clang diagnostic pop
#endif
